
#include<bits/stdc++.h>
using namespace std;

void NGE(int a[],int n)
{
	stack<int>s;
	
	s.push(a[0]);
	
	for (int i=1;i<n;i++)
	{
		if(s.empty())
		{
			s.push(a[i]);
			continue;
		}
		
		while(s.empty==fasle && s.top()<a[i]){
			
			cout << s.top() << " --> " << a[i] << endl; 
		    s.pop(); 
		}
	}
	s.push(a[i]);
	
	while (s.empty() == false) { 
	cout << s.top() << " --> " << -1 << endl; 
	s.pop(); 
}
	
}

int main(){
	
}

#implementing queue using two stacks 


#include<bits/stdc++.h>
using namespace std;

void enqueue(int x){
	stack<int>s1,s2;
	
	while(!s1.empty())
	{
	 s2.push(s1.top());
     s1.pop();	 
	 
	}
	
	s1.push(x);
	
	while(!s2.empty())
	{
		
		s1.push(S2.top());
		s2.pop();
	}
	
	
	
}

int main(){
}



#implementing stack  using two queue


#include<bits/stdc++.h>

using namespace std;

void push(int x)
{
	
queue<int >q1,q2;

q2.push(x);

while(!q1.empty())
{
	
	q2.push(q1.front());
	q1.pop();
	
	
}

queue<int>q=q1;
q1=q2;
q2=q;

	
}

void pop()
{

while(q1.empty())
{
return ;}

q.pop();
curr_size--;
	
	
}


int main()
{
}




##############################################################################################

height og binary trees
int height(node *p)
{
	if(p==NULL)
	{
		return 0;
	}
	
	int left=height(p->left);
	int right=height(p->right);
	
	if(left>right){
		
	 h=1+left;
	}
	else{
	h=1+right;}
	
	return h;
	
}

Deleting all nodes of BINARY TREES
----------------------------------

void deleteTree(node *p)
{
	if(p==NULL)
	{
	return;}
	
	deleteTree(p->left);
	deleteTree(p->right);
	free(p);
	
}


------********************************&&&&&&&&&&&&&&&&&&&&&&&&&&&&&***********************-----
---:PRINT PATH WITH GIVEN SUM:--

#include<bits/stdc++.h>
using namespace std;

int sum=0;

stack<int>s;

void printpath(node *p){
if(p==NULL)
	return;

 sum=sum+p->data;
 s.push(p->data);
 if(summ==K){
 print(stack);
 }
 
 inorder(p->left);
 
 inorder(p->right);
 
 sum=sum-p->data;
 s.pop();
 


}

int main(){
	
}

=====================================================
LONGEST INCREASING SUBSEQUENCE

#include<bits/stdc++.h>
using namespace std;

void LIS(int a[],int n){
	
	int res[n];
	for (int i=1;i<n;i++)
	{   res[i]=1;
		for(int j=0;j<i;j++)
		{
			if(a[i]>a[j] &&res[i]<res[j]+1){
				
				res[i]=res[j]+1;
			}
		}
	}
	
	return *max_element(res,res+n);
	


}



-----:ZIG -ZAG /SPIRAL LEVEL ORDER TRAVERSAL IN BINARY TREE:----
================================================================

use two stacks
steps:
push root of the tree in stack s1;
pop from s1 and print;
push in s2(left and right child of root);
pop from s2 and print;
push n s1(right and left child of root);



void spiral(node * root){
	stack<int >s1,s2;
	s1.push(root);
	while(s1.hasNodes()||s2.hasNodes())
	{
		while(s1.hasNodes())
		{
			p=s1.pop()
			print(p);
			if(p->left)
				s2.push(p->left);
			if(p->right)
				s2.push(p->right);
			
        }
		
		while(s2.hasNodes())
		{
			p=s2.pop()
			print(p);
			if(p->right)
				s1.push(p->right);
			if(p->right)
				s1.push(p->left);
			
        }

}}















